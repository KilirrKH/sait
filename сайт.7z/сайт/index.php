<?php
header("Location: /sait.php");
?>